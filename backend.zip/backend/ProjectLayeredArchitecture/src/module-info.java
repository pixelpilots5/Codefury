/**
 * 
 */
/**
 * 
 */
module ProjectLayeredArchitecture {
	requires java.sql;
}